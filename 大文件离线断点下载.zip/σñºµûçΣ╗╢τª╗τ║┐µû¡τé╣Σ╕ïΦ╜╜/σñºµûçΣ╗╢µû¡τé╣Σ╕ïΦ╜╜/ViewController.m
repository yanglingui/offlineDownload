//
//  ViewController.m
//  大文件断点下载
//
//  Created by 杨林贵 on 16/10/22.
//  Copyright © 2016年 杨林贵. All rights reserved.
//

#import "ViewController.h"

//下载的文件路径
#define FilePath  [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"download1.zip"]

//已经下载的文件大小
#define  downloadFileLength  [[[NSFileManager defaultManager] attributesOfItemAtPath:FilePath error:nil][NSFileSize] integerValue]


//该路径的字典中存放着总的下载大小
#define downloadFilePath [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"downloadFilePath.plist"]

@interface ViewController ()<NSURLSessionDataDelegate>

@property(nonatomic,strong)NSURLSessionDataTask *task;
@property(nonatomic,strong)NSURLSession *session;
@property(nonatomic,strong)NSOutputStream *stream; //已经下载的数据
@property(nonatomic,assign)NSInteger allFileLength;   //总的文件大小
@property(nonatomic,strong)NSMutableData *data;
@end

@implementation ViewController

- (NSURLSession *)session
{
    if (_session == nil) {
        _session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration] delegate:self delegateQueue:[[NSOperationQueue alloc] init]];

    }

    return _session;
}
///开始下载
- (IBAction)download:(id)sender {
    //
    
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:downloadFilePath];
    NSInteger caches =  [[dic objectForKey:downloadFilePath.lastPathComponent] integerValue];
    
    if (caches && caches == downloadFileLength) {
        NSLog(@"文件已经下载完成");
        return;
    }
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"https://github.com/ReactiveCocoa/ReactiveCocoa/archive/master.zip"]];
    //已经下载了的大小
    NSInteger downloadlength = downloadFileLength;
    
    //从downloadlength大小的地方开始下载
    [request setValue:[NSString stringWithFormat:@"bytes=%zd-",downloadlength] forHTTPHeaderField:@"Range"];
    self.task = [self.session dataTaskWithRequest:request];
    [self.task resume];
    
}
//暂停
- (IBAction)stop:(id)sender {
    [self.task suspend];
}

//恢复下载
- (IBAction)resume:(id)sender {
    [self.task resume];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%@",FilePath);

}
-(void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveResponse:(NSHTTPURLResponse *)response completionHandler:(void (^)(NSURLSessionResponseDisposition))completionHandler
{
    
    if (self.stream == nil) {
        self.stream = [[NSOutputStream alloc] initToFileAtPath:FilePath append:YES];
    }
    [self.stream open];
    
    //通过响应头获取本次下载文件的大小
    NSInteger currentLength = [response.allHeaderFields[@"content-length"] integerValue];
    //获取已经下载的文件的大小；如果总文件大小20M，上次下载了10M，那么本次的下载总大小就为10M了
    self.allFileLength = currentLength + downloadFileLength;
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithContentsOfFile:downloadFilePath];
    if (dic == nil) {
        dic = [NSMutableDictionary dictionary];
    }
    [dic setValue:@(self.allFileLength) forKey:downloadFilePath.lastPathComponent];
    [dic writeToFile:downloadFilePath atomically:YES];
    
    
    completionHandler(NSURLSessionResponseAllow);
}
-(void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveData:(NSData *)data
{
    [self.stream write:data.bytes maxLength:data.length];
    NSInteger length = downloadFileLength;
    
    NSLog(@"下载中，下载进度为：%.2f",1.0*downloadFileLength/self.allFileLength);

}
-(void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error
{
    if (error) {
        NSLog(@"下载失败");
    }else
    {
        NSLog(@"下载完成");

    }
    [self.stream close];
    self.stream = nil;
    self.task = nil;
}
@end
