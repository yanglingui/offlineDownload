//
//  main.m
//  大文件断点下载
//
//  Created by 杨林贵 on 16/10/22.
//  Copyright © 2016年 杨林贵. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
